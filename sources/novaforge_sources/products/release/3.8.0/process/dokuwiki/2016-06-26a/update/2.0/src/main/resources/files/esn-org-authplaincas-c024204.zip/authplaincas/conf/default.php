<?php
$conf['name'] = 'CAS Login';
$conf['logourl'] = '';
// $conf['localname'] = 'Local Login';
// $conf['jshidelocal'] = 1;

$conf['server'] = '';
$conf['rootcas'] = '';
$conf['port'] = '';
$conf['samlValidate'] = 0;

$conf['handlelogoutrequest'] = 0;
$conf['handlelogoutrequestTrustedHosts'] = '';

// $conf['autologin'] = 1;
// $conf['caslogout'] = 1;
// an additional switch for logging out would need to be set otherwise the user will be loged in again after the logout.
$conf['autologinout'] = 0;

$conf['localusers'] = 0;
$conf['minimalgroups'] = '';


